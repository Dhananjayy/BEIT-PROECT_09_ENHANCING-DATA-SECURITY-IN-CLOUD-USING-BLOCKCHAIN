package com.project.task;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
public class AmazonUpload {
	
	private static final String SUFFIX = "/";
	
	public static void uploadons3bucket(String bucketName,String filePath,String fileName) {
		// credentials object identifying user for authentication
		// user must have AWSConnector and AmazonS3FullAccess for 
		// this example to work
		AWSCredentials credentials = new BasicAWSCredentials(
				"AKIAWXFFKVSWRJRKAIVF", 
				"em/kFOT9F0g6l0YSeArKNet+PO9k8HD62jKnh+Lc");
		
		// create a client connection based on credentials
		AmazonS3 s3client = new AmazonS3Client(credentials);
		
		// create bucket - name must be unique for all S3 users
		//String bucketName = "my-project-bucket01";
		//s3client.createBucket(bucketName);
		
		// list buckets
		//for (Bucket bucket : s3client.listBuckets()) {
			//System.out.println(" - " + bucket.getName());
		//}
		
		// create folder into bucket
		//String folderName = "testfolder";
		//createFolder(bucketName, folderName, s3client);
		
		// upload file to folder and set it to public
		//String fileName = "myfile.txt";
		s3client.putObject(new PutObjectRequest(bucketName, fileName, 
				new File(filePath))
				.withCannedAcl(CannedAccessControlList.PublicRead));
		
		//deleteFolder(bucketName, folderName, s3client);
		
		// deletes bucket
		//s3client.deleteBucket(bucketName);
	}
	
	public static void createFolder(String bucketName, String folderName, AmazonS3 client) {
		// create meta-data for your folder and set content-length to 0
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentLength(0);
		// create empty content
		InputStream emptyContent = new ByteArrayInputStream(new byte[0]);
		// create a PutObjectRequest passing the folder name suffixed by /
		PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,
				folderName + SUFFIX, emptyContent, metadata);
		// send request to S3 to create folder
		client.putObject(putObjectRequest);
	}
	
	  public static void deleteFileFromBucket(String bucketName,String keyName){
		  AWSCredentials credentials = new BasicAWSCredentials(
					"AKIAWXFFKVSWRJRKAIVF", 
					"em/kFOT9F0g6l0YSeArKNet+PO9k8HD62jKnh+Lc");
		  AmazonS3Client s3Client = new AmazonS3Client(credentials);
		  s3Client.deleteObject(new DeleteObjectRequest(bucketName, keyName));
	  }
	
	  public static void downloadFileFromS3(String filePathtobeStored,String bucketName,String key){
		  
		AWSCredentials credentials = new BasicAWSCredentials(
					"AKIAWXFFKVSWRJRKAIVF", 
					"em/kFOT9F0g6l0YSeArKNet+PO9k8HD62jKnh+Lc");
		AmazonS3Client s3Client = new AmazonS3Client(credentials);
		//This is where the downloaded file will be saved
		File localFile = new File(filePathtobeStored);
		//This returns an ObjectMetadata file but you don't have to use this if you don't want 
		s3Client.getObject(new GetObjectRequest(bucketName,key),localFile);
		//Now your file will have your image saved 
		boolean success = localFile.exists() && localFile.canRead(); 
	 }
}

 


	/**
	 * This method first deletes all the files in given folder and than the
	 * folder itself
	 */
/*
 * public static void deleteFolder(String bucketName, String folderName,
 * AmazonS3 client) { List fileList = client.listObjects(bucketName,
 * folderName).getObjectSummaries(); for (S3ObjectSummary file : fileList) {
 * client.deleteObject(bucketName, file.getKey()); }
 * client.deleteObject(bucketName, folderName); }
 */
