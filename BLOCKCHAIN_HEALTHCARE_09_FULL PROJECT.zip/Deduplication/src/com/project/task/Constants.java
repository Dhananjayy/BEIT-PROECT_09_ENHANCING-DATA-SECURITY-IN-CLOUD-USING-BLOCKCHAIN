package com.project.task;

public class Constants {
  
	public final static String bucketbasename = "my-project-bucket0";
}
